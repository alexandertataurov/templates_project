import React from "react";

interface Props {
  isUploading: boolean;
  onClick: () => void;
}

const UploadButton: React.FC<Props> = ({ isUploading, onClick }) => {
  return (
    <button
      onClick={onClick}
      disabled={isUploading}
      className={`w-full text-white p-2 mt-4 rounded ${
        isUploading ? "bg-gray-400" : "bg-green-500"
      }`}
    >
      {isUploading ? "⏳ Загрузка..." : "✅ Загрузить"}
    </button>
  );
};

export default UploadButton;
