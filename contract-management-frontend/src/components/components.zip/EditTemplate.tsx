import { useState } from "react";
import { useUpdateTemplate } from "../api";
import { notifySuccess, notifyError } from "../components/ToastProvider";

const EditTemplate = ({ templateId, currentDisplayName, currentFields = [], onClose }: { 
  templateId: number; 
  currentDisplayName: string; 
  currentFields?: string[];
  onClose: () => void;
}) => {
  console.log("🛠 Редактирование шаблона загружено", { templateId, currentDisplayName, currentFields });

  const [displayName, setDisplayName] = useState(currentDisplayName);
  const [fields, setFields] = useState(currentFields);
  const [newField, setNewField] = useState("");
  const mutation = useUpdateTemplate();

  const handleUpdate = async () => {
    debugger; // ✅ Остановка перед обновлением
    console.log("💾 Обновление шаблона", { templateId, displayName, fields });

    if (!displayName.trim()) return notifyError("❌ Название не может быть пустым!");
    try {
      await mutation.mutateAsync({ templateId, displayName, fields });
      notifySuccess("✅ Шаблон обновлён!");
      onClose();
    } catch (error) {
      console.error("❌ Ошибка обновления шаблона:", error);
      notifyError("❌ Ошибка обновления шаблона");
    }
  };

  return (
    <div className="p-6 bg-white rounded-lg shadow-lg w-96 mx-auto">
      <h2 className="text-xl font-bold">✏️ Редактирование</h2>
      <input type="text" value={displayName} onChange={(e) => setDisplayName(e.target.value)} className="border p-2 w-full mt-4 rounded" />
      <div className="mt-4">
        <h3 className="font-semibold">Поля:</h3>
        {fields.length ? fields.map((f, i) => (
          <div key={i} className="p-2 flex justify-between">
            {f}
            <button onClick={() => {
              console.log("❌ Удалено поле:", f);
              setFields(fields.filter(x => x !== f));
            }}>❌</button>
          </div>
        )) : <p className="text-gray-500">⚠️ Нет полей</p>}
        <div className="flex mt-2">
          <input type="text" value={newField} onChange={(e) => setNewField(e.target.value)} className="border p-2 flex-1 rounded" />
          <button onClick={() => {
            console.log("➕ Добавлено поле:", newField);
            setFields([...fields, newField]);
          }} className="ml-2">➕</button>
        </div>
      </div>
      <button onClick={handleUpdate} className="w-full bg-blue-500 text-white p-2 mt-4">✅ Обновить</button>
      <button onClick={onClose} className="w-full bg-gray-300 text-gray-700 p-2 mt-2">❌ Отмена</button>
    </div>
  );
};

export default EditTemplate;
