import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

export const notifySuccess = (message: string) => {
  console.log("✅ Успешное уведомление:", message);
  toast.success(message);
};

export const notifyError = (message: string) => {
  console.error("❌ Ошибка уведомления:", message);
  toast.error(message);
};

export default function Toast() {
  return <ToastContainer position="top-right" autoClose={3000} />;
}
