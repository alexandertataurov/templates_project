import { useState } from "react";
import TemplateDetails from "./TemplateDetails";

const TemplateList = ({ templates, onDelete }: { templates: any[]; onDelete: (id: number) => void }) => {
  const [selectedTemplate, setSelectedTemplate] = useState<any | null>(null);

  const handleSave = (updatedTemplate: any) => {
    console.log("✅ Шаблон обновлён:", updatedTemplate);
    setSelectedTemplate(null); // Закрываем модалку после сохранения
  };

  return (
    <div>
      <ul>
        {templates.length === 0 ? (
          <p className="text-gray-500">⚠️ Нет шаблонов</p>
        ) : (
          templates.map((t) => (
            <li key={t.id} className="p-4 border-b border-gray-300">
              <div className="flex justify-between">
                <div>
                  <p><b>🆔 ID:</b> {t.id}</p>
                  <p><b>📅 Дата:</b> {new Date(t.created_at).toLocaleString()}</p>
                  <p><b>📜 Название:</b> {t.display_name}</p>
                  <p><b>📂 Тип:</b> {t.type}</p>
                  <p><b>📥 Скачать:</b> 
                    <a href={t.file_path} download className="text-blue-500 underline ml-2">
                      Скачать файл
                    </a>
                  </p>
                </div>
                <div className="flex space-x-2">
                  <button
                    onClick={() => setSelectedTemplate(t)}
                    className="bg-yellow-500 text-white px-3 py-1 rounded"
                  >
                    ✏️ Редактировать
                  </button>
                  <button
                    onClick={() => onDelete(t.id)}
                    className="bg-red-500 text-white px-3 py-1 rounded"
                  >
                    🗑 Удалить
                  </button>
                </div>
              </div>
            </li>
          ))
        )}
      </ul>

      {selectedTemplate && (
        <TemplateDetails 
          template={selectedTemplate} 
          onClose={() => setSelectedTemplate(null)}
          onSave={handleSave}
        />
      )}
    </div>
  );
};

export default TemplateList;
