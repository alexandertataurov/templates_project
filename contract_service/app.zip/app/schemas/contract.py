from pydantic import BaseModel, Field
from datetime import date
from decimal import Decimal
from typing import Optional


class ContractBase(BaseModel):
    contract_number: str = Field(..., max_length=50)
    contract_date: date
    valid_date: Optional[date] = None  # ✅ Новый срок действия договора
    place_of_signing: Optional[str] = None
    currency: str = "CNY"
    exchange_rate: Optional[Decimal] = None

    supplier_name: str
    supplier_representative: str
    supplier_address: str
    supplier_inn: str
    supplier_bik: str
    supplier_ogrn: str
    supplier_bank: str
    supplier_swift: str
    supplier_account: str

    buyer_name: str
    buyer_address: str
    buyer_bank: str
    buyer_swift: str
    buyer_account: str
    buyer_tax_id: Optional[str] = None  # ✅ Новый идентификатор налогоплательщика покупателя

    goods_name: str
    quantity: int
    price_per_unit: Decimal
    total_price: Decimal

    payment_date: date
    delivery_terms: str
    claim_period: int
    response_period: int

    class Config:
        orm_mode = True

class ContractCreate(ContractBase):
    pass


class ContractResponse(ContractBase):
    id: int

    class Config:
        from_attributes = True  # Позволяет Pydantic работать с SQLAlchemy
