from pydantic import BaseModel
from datetime import date
from decimal import Decimal

class SpecificationBase(BaseModel):
    spec_number: str
    spec_date: date
    goods_description: str
    price: Decimal
    volume: int
    total_amount: Decimal

class SpecificationCreate(SpecificationBase):
    pass

class SpecificationResponse(SpecificationBase):
    id: int
    contract_id: int

    class Config:
        from_attributes = True
