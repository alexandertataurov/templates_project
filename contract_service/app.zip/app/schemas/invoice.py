from pydantic import BaseModel
from datetime import date
from decimal import Decimal

class InvoiceBase(BaseModel):
    invoice_number: str
    invoice_date: date
    due_date: date
    total_amount: Decimal
    currency: str = "CNY"
    status: str = "pending"

class InvoiceCreate(InvoiceBase):
    pass

class InvoiceResponse(InvoiceBase):
    id: int
    contract_id: int

    class Config:
        from_attributes = True
