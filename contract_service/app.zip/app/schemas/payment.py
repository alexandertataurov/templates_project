from pydantic import BaseModel
from datetime import date
from decimal import Decimal

class PaymentBase(BaseModel):
    payment_date: date
    amount: Decimal
    currency: str = "CNY"
    payment_method: str
    status: str = "completed"

class PaymentCreate(PaymentBase):
    pass

class PaymentResponse(PaymentBase):
    id: int
    invoice_id: int

    class Config:
        from_attributes = True
