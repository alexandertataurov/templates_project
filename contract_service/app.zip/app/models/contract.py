from sqlalchemy import Column, Integer, String, Date, Numeric, ForeignKey
from sqlalchemy.orm import relationship
from app.models import Base

class Contract(Base):
    __tablename__ = "contracts"

    id = Column(Integer, primary_key=True, index=True)
    contract_number = Column(String(50), unique=True, nullable=False, index=True)
    contract_date = Column(Date, nullable=False)
    place_of_signing = Column(String(255), nullable=False)  # Место подписания
    valid_date = Column(Date, nullable=True)  # ✅ Добавили поле


    # Реквизиты продавца
    supplier_name = Column(String(255), nullable=False)
    supplier_representative = Column(String(255), nullable=False)

    supplier_address = Column(String(255), nullable=False)
    supplier_inn = Column(String(50), nullable=True)
    supplier_bik = Column(String(50), nullable=True)
    supplier_ogrn = Column(String(50), nullable=True)
    supplier_bank = Column(String(255), nullable=False)
    supplier_swift = Column(String(50), nullable=True)
    supplier_account = Column(String(50), nullable=False)

    # Реквизиты покупателя
    buyer_name = Column(String(255), nullable=False)
    buyer_address = Column(String(255), nullable=False)
    buyer_bank = Column(String(255), nullable=False)
    buyer_swift = Column(String(50), nullable=True)
    buyer_account = Column(String(50), nullable=False)
    buyer_tax_id = Column(String(50), nullable=False)
    
    # Данные контракта
    goods_name = Column(String(255), nullable=False)
    quantity = Column(Integer, nullable=False)
    price_per_unit = Column(Numeric(10, 2), nullable=False)
    total_price = Column(Numeric(15, 2), nullable=False)
    payment_date = Column(Date, nullable=False)

    currency = Column(String(10), nullable=False, default="CNY")
    exchange_rate = Column(Numeric(10, 4), nullable=True)
    delivery_terms = Column(String(50), nullable=False, default="CIF Владивосток")
    incoterms = Column(String(50), nullable=False, default="Incoterms 2020")
    claim_period = Column(Integer, nullable=False, default=20)
    response_period = Column(Integer, nullable=False, default=14)

    created_at = Column(Date, server_default="CURRENT_TIMESTAMP")
    updated_at = Column(Date, onupdate="CURRENT_TIMESTAMP")

    # Связи с каскадным удалением
    specifications = relationship("Specification", back_populates="contract", cascade="all, delete-orphan")
    addendums = relationship("Addendum", back_populates="contract", cascade="all, delete-orphan")
    appendices = relationship("Appendix", back_populates="contract", cascade="all, delete-orphan")
    invoices = relationship("Invoice", back_populates="contract", cascade="all, delete-orphan")
