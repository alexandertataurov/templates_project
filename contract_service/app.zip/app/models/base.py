from sqlalchemy.orm import DeclarativeBase
from sqlalchemy.sql import func
from sqlalchemy import Column, DateTime

class Base(DeclarativeBase):
    """Базовый класс моделей SQLAlchemy."""
    __abstract__ = True  # Эта модель не создаёт таблицу в БД

    created_at = Column(DateTime, server_default=func.now())  # Дата создания записи
    updated_at = Column(DateTime, onupdate=func.now())  # Дата обновления записи
