from sqlalchemy import Column, Integer, String, Date, ForeignKey
from sqlalchemy.orm import relationship
from app.models import Base

class Appendix(Base):
    __tablename__ = "appendices"

    id = Column(Integer, primary_key=True, index=True)
    contract_id = Column(Integer, ForeignKey("contracts.id", ondelete="CASCADE"), nullable=False)  # Договор
    appendix_number = Column(String, nullable=False)  # Номер приложения
    appendix_date = Column(Date, nullable=False)  # Дата подписания
    description = Column(String, nullable=True)  # Описание

    contract = relationship("Contract", back_populates="appendices")
