from fastapi import FastAPI
from app.routers import contract, addendum, stats, specification, appendix, exchange_rate, pdf
from fastapi.middleware.cors import CORSMiddleware
from app.routers import invoice

app = FastAPI(title="Contract Management API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.include_router(contract.router)
app.include_router(addendum.router)
app.include_router(stats.router)
app.include_router(specification.router)
app.include_router(appendix.router)
app.include_router(exchange_rate.router)
app.include_router(invoice.router)
app.include_router(pdf.router)

