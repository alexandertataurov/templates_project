import React, { useState, useCallback, ChangeEvent, useMemo, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button as AntButton, message, Input as AntInput } from "antd";
import { PlusOutlined, SearchOutlined } from "@ant-design/icons";
import useTemplates from "../hooks/useTemplates";
import ErrorBoundary from "./ErrorBoundary";
// Import missing types and API functions
import { Template } from "../types/template";
import { updateTemplate, deleteTemplate } from "../api/templates";
import debounce from "lodash/debounce";

/**
 * Props for the TemplateRow component.
 */
interface TemplateRowProps {
  template: Template;
  isEditing: boolean;
  tagColors: string[];
  editDisplayName: string;
  newEditField: string;
  editDynamicFields: string[];
  onEdit: (template: Template) => void;
  onUpdate: (template: Template) => void;
  onDelete: (id: number) => void;
  onCancelEdit: () => void;
  onChangeDisplayName: (value: string) => void;
  onAddEditField: () => void;
  onRemoveEditField: (field: string) => void;
  onSetNewEditField: (value: string) => void;
}

/**
 * TemplateRow renders a single row in the templates table.
 */
const TemplateRow: React.FC<TemplateRowProps> = ({
  template,
  isEditing,
  tagColors,
  editDisplayName,
  newEditField,
  editDynamicFields,
  onEdit,
  onUpdate,
  onDelete,
  onCancelEdit,
  onChangeDisplayName,
  onAddEditField,
  onRemoveEditField,
  onSetNewEditField,
}) => {
  // Utility: parse dynamic fields if provided as a comma-separated string.
  const parseDynamicFields = (fields?: string[]): string[] => {
    if (Array.isArray(fields)) {
      if (fields.length === 1 && fields[0].includes(",")) {
        return fields[0].split(",").map(f => f.trim()).filter(Boolean);
      }
      return fields;
    }
    return [];
  };

  return (
    <motion.tr
      key={template.id}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      whileHover={{ backgroundColor: "#f9fafb" }}
      transition={{ duration: 0.3 }}
    >
      <td className="template-manager__td">{template.id}</td>
      <td className="template-manager__td">
        {template.templateType || "contract"}
      </td>
      <td className="template-manager__td">
        {isEditing ? (
          <AntInput
            value={editDisplayName}
            onChange={(e) => onChangeDisplayName(e.target.value)}
            className="template-manager__input"
            status={editDisplayName.trim() ? "" : "error"}
            aria-label="Template Display Name"
          />
        ) : (
          template.displayName
        )}
      </td>
      <td className="template-manager__td">
        {isEditing ? (
          <div className="template-manager__edit-fields">
            <div className="template-manager__tags">
              {editDynamicFields.map((field, idx) => (
                <motion.span
                  key={`${template.id}-${idx}`}
                  className={`template-manager__tag ${tagColors[idx % tagColors.length]}`}
                  initial={{ scale: 0.9 }}
                  animate={{ scale: 1 }}
                  exit={{ scale: 0.9 }}
                >
                  {field}
                  <button
                    type="button"
                    onClick={() => onRemoveEditField(field)}
                    className="template-manager__tag-close"
                    aria-label={`Remove field ${field}`}
                  >
                    ×
                  </button>
                </motion.span>
              ))}
            </div>
            <div className="template-manager__field-add">
              <AntInput
                value={newEditField}
                onChange={(e) => onSetNewEditField(e.target.value)}
                onPressEnter={onAddEditField}
                placeholder="Новое поле"
                className="template-manager__input template-manager__input--flex"
                aria-label="New Field Input"
              />
              <AntButton
                type="primary"
                icon={<PlusOutlined />}
                onClick={onAddEditField}
                aria-label="Add New Field"
              />
            </div>
          </div>
        ) : (
          <div className="template-manager__tags">
            {parseDynamicFields(template.fields).map((field, idx) => (
              <span
                key={`${template.id}-${idx}`}
                className={`template-manager__tag ${tagColors[idx % tagColors.length]}`}
              >
                {field}
              </span>
            ))}
          </div>
        )}
      </td>
      <td className="template-manager__td">
        {isEditing ? (
          <div className="template-manager__actions">
            <AntButton
              type="primary"
              className="btn-save"
              onClick={() => onUpdate(template)}
            >
              Сохранить
            </AntButton>
            <AntButton
              className="btn-outline"
              onClick={onCancelEdit}
            >
              Отмена
            </AntButton>
          </div>
        ) : (
          <div className="template-manager__actions">
            <AntButton
              type="primary"
              className="btn-update"
              onClick={() => onEdit(template)}
              aria-label="Edit Template"
            >
              Редактировать
            </AntButton>
            <AntButton
              danger
              className="btn-delete"
              onClick={() => onDelete(template.id)}
              data-testid={`delete-template-${template.id}`}
              aria-label="Delete Template"
            >
              Удалить
            </AntButton>
          </div>
        )}
      </td>
    </motion.tr>
  );
};

/**
 * TemplateManager lists, filters, and allows editing/deletion of templates.
 */
const TemplateManager: React.FC = React.memo(() => {
  const { templates, loading, error, fetchTemplates } = useTemplates();
  const [editingTemplateId, setEditingTemplateId] = useState<number | null>(null);
  const [editDisplayName, setEditDisplayName] = useState<string>("");
  const [editDynamicFields, setEditDynamicFields] = useState<string[]>([]);
  const [newEditField, setNewEditField] = useState<string>("");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [debouncedQuery, setDebouncedQuery] = useState<string>("");

  const tagColors = useMemo(
    () => ["tag-0", "tag-1", "tag-2", "tag-3", "tag-4", "tag-5", "tag-6"],
    []
  );

  // Use lodash.debounce to update debouncedQuery
  const debouncedSearch = useMemo(
    () => debounce((query: string) => setDebouncedQuery(query), 300),
    []
  );

  useEffect(() => {
    debouncedSearch(searchQuery);
    return () => {
      debouncedSearch.cancel();
    };
  }, [searchQuery, debouncedSearch]);

  // Utility: parse dynamic fields from a possible comma-separated string.
  const parseDynamicFields = (fields?: string[]): string[] => {
    if (Array.isArray(fields)) {
      if (fields.length === 1 && fields[0].includes(",")) {
        return fields[0].split(",").map(f => f.trim()).filter(Boolean);
      }
      return fields;
    }
    return [];
  };

  // (Optional) isMounted flag can be used in async operations to prevent state updates on unmounted components.
  useEffect(() => {
    let isMounted = true;
    return () => {
      isMounted = false;
    };
  }, []);

  // Handlers for editing, updating, and deleting templates.
  const handleEdit = useCallback((template: Template) => {
    setEditingTemplateId(template.id);
    setEditDisplayName(template.displayName);
    setEditDynamicFields(parseDynamicFields(template.fields));
    setNewEditField("");
  }, []);

  const handleAddEditField = useCallback(() => {
    const trimmed = newEditField.trim();
    if (trimmed && !editDynamicFields.includes(trimmed)) {
      setEditDynamicFields([...editDynamicFields, trimmed]);
      setNewEditField("");
    }
  }, [newEditField, editDynamicFields]);

  const handleRemoveEditField = useCallback(
    (field: string) => {
      setEditDynamicFields(editDynamicFields.filter(f => f !== field));
    },
    [editDynamicFields]
  );

  const handleUpdate = useCallback(
    async (template: Template) => {
      if (!editDisplayName.trim()) {
        message.error("Название шаблона не может быть пустым");
        return;
      }
      try {
        await updateTemplate(template.id, {
          displayName: editDisplayName,
          fields: editDynamicFields,
        });
        await fetchTemplates();
        setEditingTemplateId(null);
        message.success("Шаблон успешно обновлен");
      } catch (err) {
        console.error("Update failed:", err);
        message.error("Ошибка обновления шаблона");
      }
    },
    [editDisplayName, editDynamicFields, fetchTemplates]
  );

  const handleDelete = useCallback(
    async (templateId: number) => {
      if (window.confirm("Вы уверены, что хотите удалить этот шаблон?")) {
        try {
          await deleteTemplate(templateId);
          message.success("Шаблон успешно удален");
          await fetchTemplates();
        } catch (error) {
          message.error("Ошибка удаления шаблона");
        }
      }
    },
    [fetchTemplates]
  );

  // Filter templates using the debounced search query.
  const filteredTemplates = useMemo(() => {
    return templates.filter((template) =>
      (template.display_name || "").toLowerCase().includes(debouncedQuery.toLowerCase())
    );
  }, [templates, debouncedQuery]);

  return (
    <ErrorBoundary>
      <motion.div
        className="template-manager"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h2 className="template-manager__title">Управление шаблонами</h2>
        <div className="template-manager__controls">
          <AntInput
            prefix={<SearchOutlined />}
            placeholder="Поиск шаблонов..."
            value={searchQuery}
            onChange={(e: ChangeEvent<HTMLInputElement>) => setSearchQuery(e.target.value)}
            className="template-manager__search-input"
            size="large"
            aria-label="Search Templates"
          />
          <AntButton
            type="primary"
            size="large"
            onClick={fetchTemplates}
            className="btn-update"
            aria-label="Refresh Templates"
          >
            Обновить
          </AntButton>
        </div>

        <AnimatePresence>
          {loading ? (
            <motion.div
              className="template-manager__loading"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <svg
                className="w-8 h-8 text-blue-500 animate-spin"
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
              >
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
              </svg>
            </motion.div>
          ) : error ? (
            <motion.div
              className="template-manager__error"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              {error}
            </motion.div>
          ) : filteredTemplates.length === 0 ? (
            <motion.div
              className="template-manager__no-results"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              Шаблоны не найдены
            </motion.div>
          ) : (
            <motion.div
              className="template-manager__table-container"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3 }}
            >
              <table className="template-manager__table">
                <thead>
                  <tr>
                    <th className="template-manager__th">ID</th>
                    <th className="template-manager__th">Тип</th>
                    <th className="template-manager__th">Название</th>
                    <th className="template-manager__th">Поля</th>
                    <th className="template-manager__th">Действия</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredTemplates.map((template) => (
                    <TemplateRow
                      key={template.id}
                      template={template}
                      isEditing={editingTemplateId === template.id}
                      tagColors={tagColors}
                      editDisplayName={editDisplayName}
                      newEditField={newEditField}
                      editDynamicFields={editDynamicFields}
                      onEdit={handleEdit}
                      onUpdate={handleUpdate}
                      onDelete={handleDelete}
                      onCancelEdit={() => setEditingTemplateId(null)}
                      onChangeDisplayName={setEditDisplayName}
                      onAddEditField={handleAddEditField}
                      onRemoveEditField={handleRemoveEditField}
                      onSetNewEditField={setNewEditField}
                    />
                  ))}
                </tbody>
              </table>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </ErrorBoundary>
  );
});

export default TemplateManager;
